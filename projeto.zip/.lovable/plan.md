## O que será construído

Um app web de uma página onde você faz upload de 3 arquivos `.xlsx` (CelCash, MaisTodos e Bugados), clica em **Processar** e baixa a planilha final consolidada em Excel, já com Bugados removidos e duplicados eliminados (MaisTodos com prioridade).

Tudo roda no navegador — nenhum dado é enviado para servidor.

---

## Tutorial: como preparar suas planilhas

Antes de subir os arquivos, cada planilha precisa estar exatamente neste formato (a primeira linha é cabeçalho, os dados começam na linha 2):

**Planilha CelCash** (`.xlsx`)
- Coluna **A** → Nome do cliente
- Coluna **B** → Número (telefone/CPF — o programa usa os últimos 11 dígitos)
- Coluna **C** → Parcela

**Planilha MaisTodos** (`.xlsx`)
- Coluna **A** → Nome do cliente
- Coluna **B** → Número
- Coluna **C** → Parcela

**Planilha Bugados** (`.xlsx`)
- Coluna **A** → Nome do cliente bugado
- Coluna **B** → Número do cliente bugado
- (Coluna C não é usada)

Observações:
- O nome das abas dentro do Excel não importa — o programa lê a primeira aba de cada arquivo.
- Linhas vazias são ignoradas automaticamente.
- A comparação de números ignora pontuação, espaços e usa só os **últimos 11 dígitos** (mesma regra da sua fórmula).
- A comparação de nomes é case-insensitive e ignora espaços extras.

---

## Como o programa processa (replicando a fórmula)

```text
1. Lê CelCash, MaisTodos e Bugados
2. Para CelCash → remove linhas cujo NOME está em Bugados
                → remove linhas cujo NÚMERO (últimos 11 dígitos) está em Bugados
3. Para MaisTodos → mesma limpeza com Bugados
4. Remove duplicados entre CelCash e MaisTodos:
   - Se o mesmo número aparecer nos dois → mantém MaisTodos, descarta CelCash
5. Junta tudo em uma única tabela:
   A=Nome | B=Número | C=Parcela | D=Origem (CelCash/MaisTodos)
6. Gera arquivo .xlsx para download
```

> Diferença em relação à sua fórmula original: você pediu **MaisTodos como prioridade** nos duplicados; a fórmula do Sheets prioriza CelCash. Ajustei a lógica para o que você pediu.

---

## Interface do app

Página única, layout limpo:

```text
┌─────────────────────────────────────────────┐
│  Consolidador de Planilhas                  │
│  Junta CelCash + MaisTodos, remove Bugados  │
├─────────────────────────────────────────────┤
│  [ 📄 CelCash.xlsx        ] [Selecionar]   │
│  [ 📄 MaisTodos.xlsx      ] [Selecionar]   │
│  [ 📄 Bugados.xlsx        ] [Selecionar]   │
│                                             │
│           [ Processar planilhas ]           │
├─────────────────────────────────────────────┤
│  Resumo após processar:                     │
│   • CelCash: 320 linhas → 280 após limpeza  │
│   • MaisTodos: 410 → 390 após limpeza       │
│   • Duplicados removidos: 35                │
│   • Total final: 635 clientes               │
│                                             │
│         [ ⬇ Baixar resultado.xlsx ]         │
└─────────────────────────────────────────────┘
```

Inclui também uma seção "Como preparar suas planilhas" com o tutorial acima visível na própria tela, para consulta rápida.

---

## Detalhes técnicos

- **Stack**: TanStack Start (já configurado), processamento 100% client-side com a biblioteca `xlsx` (SheetJS) — leitura dos `.xlsx`, geração do arquivo final e download via Blob.
- **Sem backend / sem upload para servidor**: tudo acontece no navegador, então funciona offline e os dados dos clientes nunca saem da máquina.
- **Validação**: se um arquivo estiver vazio ou faltando colunas obrigatórias, mostra erro amigável antes de processar.
- **Normalização de número**: `String(valor).replace(/\D/g, '').slice(-11)` (equivalente ao `RIGHT(REGEXREPLACE(...; "\D"; ""); 11)` da fórmula).
- **Normalização de nome**: `String(nome).trim().toLowerCase()` (equivalente ao `LOWER(TRIM(...))`).
- Substitui o placeholder atual em `src/routes/index.tsx` pela nova interface.
